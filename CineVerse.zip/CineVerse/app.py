from flask import Flask, render_template, url_for, request, redirect
from models.shared import db
from models.booking import Booking

# create the app
app = Flask(__name__)
# configure the SQLite database, relative to the app instance folder
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///CineVerse.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# initialize the app with the extension
db.init_app(app)

# Create the Database
with app.app_context():
    db.create_all()

@app.route('/', methods=['POST', 'GET'])
def index():
    if request.method == 'POST':
        booking_content = request.form['content']
        new_booking = Booking(content=booking_content)

        try:
            db.session.add(new_booking)
            db.session.commit()
            return redirect('/')
        except:
            return 'There was an issue adding your data'

    else:
        bookings = Booking.query.order_by(Booking.date_created).all()
        return render_template('index.html', bookings=bookings)


@app.route('/delete/<int:id>')
def delete(id):
    booking_to_delete = Booking.query.get_or_404(id)

    try:
        db.session.delete(booking_to_delete)
        db.session.commit()
        return redirect('/')
    except:
        return 'There was a problem deleting that data'

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update(id):
    booking = Booking.query.get_or_404(id)

    if request.method == 'POST':
        booking.content = request.form['content']

        try:
            db.session.commit()
            return redirect('/')
        except:
            return 'There was an issue updating your data'

    else:
        return render_template('update.html', booking=booking)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
