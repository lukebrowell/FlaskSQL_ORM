from flask_sqlalchemy import SQLAlchemy

#this shared file module is imported into all of the models

# instantiate the DB class
db = SQLAlchemy()



