from sqlalchemy import Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from datetime import datetime
from models.shared import db

# configure a data model using the declarative ORM mapper style
class Booking(db.Model):
    id: Mapped[int] = mapped_column(primary_key=True)
    content: Mapped[str] = mapped_column(String(50), nullable=False)
    date_created: Mapped[DateTime] = mapped_column(DateTime, default=datetime.utcnow)
    def __repr__(self):
         return '<Booking %r>' % self.id